#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <ctype.h>
#include <string.h>

// Function prototype for asking questions
int ask_question(int min, int max, int difficulty);

int main() {
    do {
        srand(time(NULL)); // Seed random number generator

        // Declare variables
        int userScore, totalQuestions, lives, max_num;
        char difficulty_input[10];

        // Define arrays for difficulty options
        char *easy_options[] = {"1", "e", "easy"};
        char *medium_options[] = {"2", "m", "medium"};
        char *hard_options[] = {"3", "h", "hard"};

        // Array of difficulty option arrays
        char **difficulty_options[3] = {easy_options, medium_options, hard_options};

        userScore = 0; // Initialize user's score to 0

        // Print welcome message and prompt for difficulty selection
        printf("Welcome to the Maths Test Pro.\n");
        printf("Select difficulty:\n");
        printf("1) Easy\n");
        printf("2) Medium\n");
        printf("3) Hard\n");
        printf("Enter your choice: ");

        // Read user input for difficulty selection
        scanf("%s", difficulty_input);

        // Convert input to lowercase for comparison
        for (int i = 0; difficulty_input[i]; i++) {
            difficulty_input[i] = tolower(difficulty_input[i]);
        }

        int difficulty;
        bool valid_difficulty = false;

        // Check if user input matches any of the difficulty options
        for (int i = 0; i < 3; i++) {
            char **options;
            int num_options;
            if (i == 0) {
                options = easy_options;
                num_options = 3;
            } else if (i == 1) {
                options = medium_options;
                num_options = 3;
            } else if (i == 2) {
                options = hard_options;
                num_options = 3;
            }
            for (int j = 0; j < num_options; j++) {
                char *option = options[j];
                int k;
                for (k = 0; difficulty_input[k] && option[k]; k++) {
                    if (tolower(difficulty_input[k]) != tolower(option[k])) {
                        break;
                    }
                }
                if (difficulty_input[k] == '\0' && option[k] == '\0') {
                    difficulty = i + 1;
                    valid_difficulty = true;
                    break;
                }
            }
            if (valid_difficulty)
                break;
        }

        // If difficulty is not valid, exit program
        if (!valid_difficulty) {
            printf("Invalid choice. Exiting.\n");
            return 1;
        }

        // Set variables based on selected difficulty
        if (difficulty == 1) {
            lives = 3;
            max_num = 10;
            totalQuestions = 5;
            printf("Easy mode selected.\n");
        } else if (difficulty == 2) {
            lives = 2;
            max_num = 30;
            totalQuestions = 10;
            printf("Medium mode selected.\n");
        } else if (difficulty == 3) {
            lives = 1;
            max_num = 60;
            totalQuestions = 15;
            printf("Hard mode selected.\n");
        } else {
            printf("Invalid choice. Exiting.\n");
            return 1;
        }

        // Loop to administer questions
        int numQuestions = totalQuestions;
        for (int questionIndex = 0; questionIndex < totalQuestions; questionIndex++) {
            char *lifeText;
            switch (lives) {
                case 1:
                    lifeText = "life";
                    break;
                default:
                    lifeText = "lives";
            }
            printf("\nQuestion %d/%d. You have %d %s remaining.\n",
                    questionIndex + 1, totalQuestions, lives, lifeText);
            if (questionIndex == totalQuestions - 1)
                printf("Challenge question!\n");

            if (ask_question(1, (questionIndex == totalQuestions - 1) ? max_num * 2 : max_num, difficulty))
                userScore++;
            else
                lives--;

            if (lives == 0) {
                printf("Out of lives, game over!\n");
                break;
            }
        }

        float userPercentage_float = ((float) userScore / totalQuestions) * 100.0;
        int userPercentage = (int)userPercentage_float;
        printf("You scored %d/%d (", userScore, totalQuestions);
        printf("%.0f%%).\n", userPercentage_float);

        if (userPercentage >= 80)
            printf("Grade: High Distinction\n");
        else if (userPercentage >= 70)
            printf("Grade: Distinction\n");
        else if (userPercentage >= 60)
            printf("Grade: Credit\n");
        else if (userPercentage >= 50)
            printf("Grade: Pass\n");
        else
            printf("Grade: Fail\n");

        // Ask user if they want to start again
        char choice;
        printf("Do you wish to start again? (y/n): ");
        scanf(" %c", &choice);
        if (choice != 'y' && choice != 'Y')
            break;

    } while (1);

    return 0;
}

// Function to ask a question based on given parameters
int ask_question(int min, int max, int difficulty) {
    int firstNumber, secondNumber;

    // Loop until two unique random numbers are generated
    do {
        firstNumber = rand() % (max - min + 1) + min;
        secondNumber = rand() % (max - min + 1) + min;
    } while (firstNumber == secondNumber);

    char operators[4]; // Increased size to accommodate the terminating null character
    int num_operators;
    if (difficulty == 3) {
        operators[0] = '+';
        operators[1] = '-';
        operators[2] = 'x';
        operators[3] = '/';
        num_operators = 4;
    } else {
        operators[0] = '+';
        operators[1] = '-';
        num_operators = 2;
    }
    operators[num_operators] = '\0';

    char operator = operators[rand() % num_operators];

    if (operator == '/') {
        if (secondNumber == 0)
            secondNumber++;
        firstNumber *= secondNumber;
    }

    printf("What is %d %c %d? ", firstNumber, operator, secondNumber);

    int userAnswer;
    scanf("%d", &userAnswer);

    int correctAnswer;
    switch (operator) {
        case '+':
            correctAnswer = firstNumber + secondNumber;
            break;
        case '-':
            correctAnswer = firstNumber - secondNumber;
            break;
        case 'x':
            correctAnswer = firstNumber * secondNumber;
            break;
        case '/':
            correctAnswer = firstNumber / secondNumber;
            break;
    }

    if (userAnswer == correctAnswer) {
        printf("Correct!\n");
        return 1;
    } else {
        printf("Incorrect! The correct answer is %d.\n", correctAnswer);
        return 0;
    }
}
